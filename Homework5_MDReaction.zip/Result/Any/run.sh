#!/bin/bash
#SBATCH -J SSN
#SBATCH --ntasks 4
#SBATCH --cpus-per-task 1
#SBATCH --account icn85
#SBATCH -o %x-%j.out
#SBATCH -e %x-%j.err
#SBATCH -q gp_resa
#SBATCH -t 00:30:00
#SBATCH -D .

module load hdf5
module load pnetcdf
module load elpa
module load netcdf
module load siesta/5.0.1

export SRUN_CPUS_PER_TASK=${SLURM_CPUS_PER_TASK}

name='xoc'

SIESTA=siesta

echo " ==> Running SIESTA as srun ${SIESTA} ${name}.fdf"
srun ${SIESTA} ${name}.fdf > ${name}.out
echo " ===> SIESTA finished"